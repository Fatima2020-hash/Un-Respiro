

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:unrespiro/screens/home_screen/instagram/instagram.dart';

import '../../model/res/constant/app_assets.dart';
import '../../model/res/constant/app_colors.dart';
import '../../provider/theme/theme_provider.dart';
import 'home_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  // var currentPage = 0;
  List<Widget> pages = [ HomeScreen(), const Instagram(),];
  int _selectedIndex = 0;


  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final _isDark = themeProvider.isDarkMode;
    return Scaffold(

      body: IndexedStack(

        index: _selectedIndex,
        children: pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Image.asset(
              AppAssets.logo,
              height: 30,
              color: _isDark ? AppColors.appYellowColor : AppColors.appRedColor,
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Image.asset(
              AppAssets.home,
              height: 30,
              color: _isDark ? AppColors.appYellowColor : AppColors.appRedColor,
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Image.asset(
              AppAssets.menu,
              height: 30,
              color: _isDark ? AppColors.appYellowColor : AppColors.appRedColor,
            ),
            label: '',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Color(0xFFEDE7F6),
        onTap:  (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),


    );
  }
}
