import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../model/res/components/toggle_button.dart';
import '../../model/res/constant/app_colors.dart';
import '../../model/res/widgets/app_text.dart.dart';
import '../../provider/theme/theme_provider.dart';

class FocusScreenO extends StatelessWidget {
  const FocusScreenO({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final _isDark = themeProvider.isDarkMode;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: AppTextWidget(text: 'Focus Mode',fontSize: 16,),
        centerTitle: true,
        actions: [
          Switch(
            value: themeProvider.isDarkMode,
            onChanged: (value) {
              themeProvider.toggleTheme();
            },
          ),
        ],
      ),
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
            color:Colors.black
                ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
                flex: 6,
                child: Container(
                  width: double.infinity,
                  decoration:  BoxDecoration(
                    color: _isDark ?  Color(0xff111111) : AppColors.appPurpleColor,
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(200),
                      bottomRight: Radius.circular(200),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(40.0),
                    child: Column(
                      children: [
                        ToggleButton(),


                      ],
                    ),
                  ),
                )),
            Expanded(
              flex: 4,
              child: Padding(
                padding:
                const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [

                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
