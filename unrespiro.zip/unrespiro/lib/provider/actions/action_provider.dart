import 'package:flutter/cupertino.dart';

class ActionProvider extends ChangeNotifier {
  bool _isVisible = true;

  bool get isVisible => _isVisible;

  void toggleVisibility() {
    _isVisible = !_isVisible;
    notifyListeners();
  }

  void hide() {
    _isVisible = false;
    notifyListeners();
  }
}