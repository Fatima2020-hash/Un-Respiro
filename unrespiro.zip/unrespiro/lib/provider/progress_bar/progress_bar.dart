import 'package:flutter/material.dart';

class ProgressModel with ChangeNotifier {
  final Map<String, Duration> _progress = {
    'Lunes': Duration(minutes: 30),
    'Martes': Duration(minutes: 45),
    'Miercoles': Duration(minutes: 27),
    'Jueves': Duration(hours: 1, minutes: 10),
    'Viernes': Duration(hours: 1, minutes: 30),
    'Sabado': Duration(minutes: 40),
    'Domingo': Duration(minutes: 10),
  };

  Map<String, Duration> get progress => _progress;
}
