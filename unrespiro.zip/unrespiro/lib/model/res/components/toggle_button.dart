import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../provider/toggle/toggle_provider.dart';

class ToggleButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var toggleModel = Provider.of<ToggleModel>(context);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: () {
            if (toggleModel.isCronometer) toggleModel.toggle();
          },
          child: Container(
            decoration: BoxDecoration(
              color: toggleModel.isCronometer ? Colors.black : Colors.orange,
              borderRadius: BorderRadius.horizontal(
                left: Radius.circular(30.0),
              ),
            ),
            padding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 20.0),
            child: Text(
              'Timer',
              style: TextStyle(
                color: toggleModel.isCronometer ? Colors.white : Colors.black,
              ),
            ),
          ),
        ),
        GestureDetector(
          onTap: () {
            if (!toggleModel.isCronometer) toggleModel.toggle();
          },
          child: Container(
            decoration: BoxDecoration(
              color: toggleModel.isCronometer ? Colors.orange : Colors.black,
              borderRadius: BorderRadius.horizontal(
                right: Radius.circular(30.0),
              ),
            ),
            padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
            child: Text(
              'Cronometer',
              style: TextStyle(
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }
}