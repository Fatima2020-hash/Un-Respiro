class RoutesName{
  static const splashScreen = "/splash_screen";
  static const confirmScreen = "/confirm_screen";
  static const loginScreen = "/login_screen";
  static const permissionScreen = "/permission_screen";
  static const mainScreen = "/main_screen";
  static const homeScreen = "/home_screen";
  static const Instagram = "/instagram";
  static const Update = "/update";
  static const focusScreenO = "/focusScreenO";
}