import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../model/background/background_services.dart';

class BackgroundServiceProvider with ChangeNotifier {
  final BackgroundService _backgroundService = BackgroundService();

  bool _isRunning = false;

  bool get isRunning => _isRunning;

  Future<void> startService() async {
    await _backgroundService.initializeService();
    _isRunning = true;
    notifyListeners();
  }

  void stopService() async {
   await  _backgroundService.stopService();
    _isRunning = false;
    notifyListeners();
  }
}
