import 'package:flutter/material.dart';

class DropdownProvider with ChangeNotifier {
  String _selectedOption = "Monthly"; // Default option
  Map<int, bool> _dropdownVisibility = {}; // Track visibility for each dropdown by index

  String get selectedOption => _selectedOption;
  bool isDropdownVisible(int index) => _dropdownVisibility[index] ?? false;

  void setSelectedOption(String option) {
    _selectedOption = option;
    notifyListeners();
  }

  void toggleDropdownVisibility(int index) {
    _dropdownVisibility[index] = !(isDropdownVisible(index));
    notifyListeners();
  }

  void closeOtherDropdowns(int index) {
    _dropdownVisibility.forEach((key, value) {
      if (key != index) {
        _dropdownVisibility[key] = false;
      }
    });
    notifyListeners();
  }
}
