import 'package:flutter/material.dart';
import 'package:device_apps/device_apps.dart';

class AppSelectionProvider with ChangeNotifier {
  final Set<String> _selectedPackages = Set<String>();

  List<Application> _selectedApps = [];

  Set<String> get selectedPackages => _selectedPackages;
  List<Application> get selectedApps => _selectedApps;

  void toggleApp(Application app) {
    if (_selectedPackages.contains(app.packageName)) {
      _selectedPackages.remove(app.packageName);
      _selectedApps.removeWhere((a) => a.packageName == app.packageName);
    } else {
      _selectedPackages.add(app.packageName);
      _selectedApps.add(app);
    }
    notifyListeners();
  }
}
