import 'package:flutter/services.dart';

class AppLauncher {
  static const platform = MethodChannel('com.example.yourapp/launch');

  static Future<void> launchApp(String packageName) async {
    try {
      await platform.invokeMethod('launchCustomScreen', {'PACKAGE_NAME': packageName});
    } on PlatformException catch (e) {
      print("Failed to launch app: '${e.message}'.");
    }
  }
}
