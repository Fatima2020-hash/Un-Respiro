import 'package:flutter/services.dart';

class AppManager {
  static const platform = MethodChannel('com.example.app/installedApps');

  static Future<void> openApp(String packageName) async {
    try {
      await platform.invokeMethod('openApp', {'packageName': packageName});
    } on PlatformException catch (e) {
      print("Failed to open app: '${e.message}'.");
    }
  }
}
