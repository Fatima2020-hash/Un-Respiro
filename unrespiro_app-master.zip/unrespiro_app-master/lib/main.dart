import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import 'package:device_preview/device_preview.dart';
import 'package:unrespiroapp/model/background/background_services.dart';
import 'package:unrespiroapp/provider/actions/action_provider.dart';
import 'package:unrespiroapp/provider/app_selection/app_selection_provider.dart';
import 'package:unrespiroapp/provider/background/background_services_provider.dart';
import 'package:unrespiroapp/provider/dropdown/dropdown_provider.dart';
import 'package:unrespiroapp/provider/matrics_progess/matrics_provider.dart';
import 'package:unrespiroapp/provider/navigation/navigation_provider.dart';
import 'package:unrespiroapp/provider/plan/plan_provider.dart';
import 'package:unrespiroapp/provider/progress_bar/progress_bar.dart';
import 'package:unrespiroapp/provider/theme/theme_provider.dart';
import 'package:unrespiroapp/provider/timer_provider/timer_provider.dart';
import 'package:unrespiroapp/provider/toggle/toggle_provider.dart';
import 'package:workmanager/workmanager.dart';


import 'constant.dart';
import 'model/res/routes/routes.dart';
import 'model/res/routes/routes_name.dart';
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) {
    // This is the background task
    log("Executing background task: $task");
    log("Executing background task on ios: $task");
    return Future.value(true);
  });
}
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await Permission.notification.isDenied.then((value) => {
    if(value){
      Permission.notification.request()
    }
  });
  await BackgroundService().initializeService();
  Workmanager().initialize(callbackDispatcher, isInDebugMode: true);
  Workmanager().registerPeriodicTask("taskName", "simpleTask");
  Workmanager().registerOneOffTask("IosBackgroundFetch", "simpleTask");
  await ThemeProvider().loadThemeMode();
  runApp(DevicePreview(
    enabled: false,
    builder: (context) => const MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Sizer(
        builder: (context, orientation,deviceType){
          return MultiProvider(
            providers: [
              ChangeNotifierProvider(create: (_) => ThemeProvider()),
              ChangeNotifierProvider(create: (_) => AppSelectionProvider()),
              ChangeNotifierProvider(create: (_) => NavigationProvider()),
              ChangeNotifierProvider(create: (_) => ActionProvider()),
              ChangeNotifierProvider(create: (_) => ProgressModel()),
              ChangeNotifierProvider(create: (_) => ToggleModel()),
              ChangeNotifierProvider(create: (_) => PlanProvider()),
              ChangeNotifierProvider(create: (_) => MatricsPercentageProvider()),
              ChangeNotifierProvider(create: (_) => DropdownProvider()),
              ChangeNotifierProvider(create: (_) => TimerProvider()),
              ChangeNotifierProvider(create: (_) => BackgroundServiceProvider()),

            ],
            child: Consumer<ThemeProvider>(
              builder: (context, provider, child) {
                return GetMaterialApp(
                  debugShowCheckedModeBanner: false,
                  title: 'Un Respiro',
                  themeMode: provider.themeMode,
                  theme: ThemeData(
                    primaryColor: primaryColor,
                    useMaterial3: true,
                    colorScheme: const ColorScheme.light(
                      primary: primaryColor,
                    ),
                  ),
                  darkTheme: ThemeData(
                    primaryColor: primaryColor,
                    useMaterial3: true,
                    scaffoldBackgroundColor: Colors.black,
                    colorScheme: const ColorScheme.dark(
                      primary: primaryColor,
                      surface: Colors.black,
                    ),
                  ),
                  initialRoute: RoutesName.splashScreen,
                  getPages: Routes.routes,
                  builder: DevicePreview.appBuilder, // Add this line
                );
              },
            ),
          );
        }
    );
  }
}