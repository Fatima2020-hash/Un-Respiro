import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:unrespiroapp/provider/background/background_services_provider.dart';

import '../../constant.dart';
import '../../model/res/constant/app_assets.dart';
import '../../model/res/constant/app_colors.dart';
import '../../model/res/constant/app_string.dart';
import '../../model/res/routes/routes_name.dart';
import '../../model/res/widgets/app_text.dart.dart';
import '../../model/res/widgets/button_widget.dart';
import '../../provider/theme/theme_provider.dart';
class ConfirmScreen extends StatelessWidget {
  const ConfirmScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final _isDark = themeProvider.isDarkMode;
    return Scaffold(
      // appBar: AppBar(
      //   title: Text('Flutter Theme Provider'),
      //   actions: [
      //     Switch(
      //       value: themeProvider.isDarkMode,
      //       onChanged: (value) {
      //         themeProvider.toggleTheme();
      //       },
      //     ),
      //   ],
      // ),
      body: Consumer<BackgroundServiceProvider>(
       builder: (context, provider, child){
         return Stack(
           children: [
             Container(
               height: double.infinity,
               decoration: BoxDecoration(
                   color: _isDark ?Colors.black:Color(0xffEAE1E1)

               ),
             ),
             Padding(
               padding:  EdgeInsets.all(Get.width * 0.15),
               child: Column(
                 mainAxisAlignment: MainAxisAlignment.center,
                 crossAxisAlignment: CrossAxisAlignment.center,
                 children: [
                   SizedBox(
                       width: Get.width,
                       height: Get.width * 0.8,
                       child: Image.asset(
                         _isDark ?AppAssets.mobileBlackImage:AppAssets.mobileImage,
                         fit: BoxFit.cover,)),
                   //SizedBox(height: Get.width * 0.12,),
                   AppTextWidget(
                     text: AppString.confirm_text,
                     color: _isDark ?Colors.white: Colors.black,
                     fontWeight: FontWeight.w400,fontSize: 14.0,textAlign: TextAlign.center,),
                   SizedBox(height: Get.width * 0.12,),
                   ButtonWidget(text: "Login",
                       fontWeight: FontWeight.w700,
                       // onClicked: (){
                       //   Get.toNamed(RoutesName.loginScreen);
                       // },
                       onClicked: () async{
                       // if(!provider.isRunning){
                       //   await provider.startService();
                       // }

                         FlutterBackgroundService().invoke('setAsForeground');

                       },
                       width: Get.width * 0.54, height: 40.0),
                   const SizedBox(height: 10.0,),
                   ButtonWidget(

                     text: "Register", onClicked: (){
                     FlutterBackgroundService().invoke('setAsBackground');
                   },
                     fontWeight: FontWeight.w600,
                     width: Get.width * 0.54,
                     height: 40.0,
                     borderColor: _isDark ?AppColors.appYellowColor : AppColors.appRedColor,
                     oneColor: true,
                     isShadow: _isDark ? true : false,
                     textColor: _isDark ? Colors.white :AppColors.appRedColor,
                     backgroundColor: _isDark ? darkGrey : Color(0xffEAE1E1),
                   ),
                 ],
               ),
             ),
           ],
         );
       },
      ),
    );
  }
}
