import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:provider/provider.dart';
import 'package:unrespiroapp/constant.dart';

import '../../model/res/constant/app_assets.dart';
import '../../model/res/constant/app_string.dart';
import '../../model/res/routes/routes_name.dart';
import '../../model/res/widgets/app_text.dart.dart';
import '../../model/res/widgets/button_widget.dart';
import '../../provider/theme/theme_provider.dart';
import '../../provider/timer_provider/timer_provider.dart';

class TimerScreen extends StatelessWidget {
  const TimerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final _isDark = themeProvider.isDarkMode;
    final timerProvider = Provider.of<TimerProvider>(context);

    return Scaffold(
      body: Stack(
        children: [
          _isDark
              ? Container(
                  height: double.infinity,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(
                          AppAssets.permissionBackground,
                        ),
                        fit: BoxFit.fill,
                        opacity: 0.8),
                  ),
                )
              : Container(
                  height: double.infinity,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Color(0xffEAE1E1),
                  ),
                ),
          Padding(
            padding: EdgeInsets.all(Get.width * 0.15),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                    width: Get.width * 0.5,
                    height: Get.width * 0.30,
                    child: Image.asset(
                      _isDark
                          ? AppAssets.loginImage
                          : AppAssets.loginImageWhite,
                      fit: BoxFit.contain,
                    )),
                SizedBox(
                    width: Get.width,
                    height: Get.width * 0.30,
                    child: Image.asset(
                      _isDark ? AppAssets.logoTimer : AppAssets.logoTimer,
                      fit: BoxFit.contain,
                    )),
                SizedBox(
                  height: Get.width * 0.05,
                ),
                AppTextWidget(
                  text: '${timerProvider.seconds}',
                  fontSize: 22.0,
                  fontWeight: FontWeight.w700,
                ),
                SizedBox(
                  height: Get.height * 0.01,
                ),
                AppTextWidget(
                  text: 'Attempts to enter in the\n last 24 hours',
                  fontWeight: FontWeight.w400,
                  fontSize: 9.0,
                  color: Colors.grey.shade300,
                  textAlign: TextAlign.center,
                ),
                SizedBox(
                  height: Get.width * 0.09,
                ),
                const AppTextWidget(
                  text: 'Are you sure you want to enter?',
                  fontWeight: FontWeight.w400,
                  fontSize: 10.0,
                  textAlign: TextAlign.center,
                ),
                SizedBox(
                  height: Get.height * 0.03,
                ),
                ButtonWidget(
                    text: "Go out",
                    fontWeight: FontWeight.w700,
                    onClicked: () {
                      SystemNavigator.pop();
                     // Get.offAndToNamed(RoutesName.mainScreen);
                    },
                    width: Get.width * 0.40,
                    height: 30.0),
                SizedBox(
                  height: Get.width * 0.05,
                ),
                GestureDetector(
                  onTap: () {
                    Get.offAndToNamed(RoutesName.Instagram);
                  },
                  child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Color(0xffFF941F)),
                      ),
                      child: Center(
                        child: AppTextWidget(
                          text: "Get Into",
                          color: Color(0xffFF941F),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      width: Get.width * 0.40,
                      height: 30.0),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
