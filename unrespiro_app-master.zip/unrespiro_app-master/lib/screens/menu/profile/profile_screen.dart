import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import '../../../constant.dart';
import '../../../model/res/components/appbar.dart';
import '../../../model/res/constant/app_assets.dart';
import '../../../model/res/constant/app_colors.dart';
import '../../../model/res/routes/routes_name.dart';
import '../../../model/res/widgets/app_text.dart.dart';
import '../../../model/res/widgets/hours_text.dart';
import '../../../provider/theme/theme_provider.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final _isDark = themeProvider.isDarkMode;

    return Scaffold(
      backgroundColor: _isDark? Colors.black:Color(0xffF9F4F4),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: SizedBox(
          height: 100.h,
          child: Stack(
            children: [
              Container(
                height: 63.h,
                width: 100.w,
                decoration: _isDark
                    ? const BoxDecoration(
                  image: DecorationImage(image: AssetImage(AppAssets.blackProfileRounded)),
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(150),
                    bottomLeft: Radius.circular(150),
                  ),
                )
                    : const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(
                        AppAssets.profileBgShadow
                    ),
                    fit: BoxFit.cover,
                  ),
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(150),
                    bottomLeft: Radius.circular(150),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 13.h,
                    ),
                    AppTextWidget(
                      text: 'Natalia',
                      fontSize: 16,
                      color: _isDark ? Colors.white : Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                    SizedBox(
                      height: 1.h,
                    ),
                    const AppTextWidget(
                      text: 'Nata03@gmail.com',
                      color: AppColors.appBarColor,
                    ),
                    SizedBox(
                      height: 2.h,
                    ),
                    Container(
                      height: 18,
                      width: 60,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: _isDark
                            ? AppColors.appYellowColor
                            : AppColors.appRedColor,
                      ),
                      child: const AppTextWidget(text: 'PRO',color: Colors.white,),
                    ),
                    SizedBox(
                      height: 4.h,
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          HoursText(
                              text: '32',
                              text2: 'Hours',
                              text3: 'Saved',
                              text4: 'hrs'),
                          HoursText(
                              text: '60',
                              text2: 'Attempts',
                              text3: 'blocked',
                              text4: 'hrs'),
                          HoursText(
                              text: '09',
                              text2: 'Blocked',
                              text3: 'apps',
                              text4: '')
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              AppbarWidget(
                text: 'PROFILE',
                fontSize: 16,
                color: primaryColor,
                image: _isDark ? AppAssets.profileRounded:AppAssets.whiteProfileRounded,
                textColor: _isDark ? Colors.white : Colors.black,
                icon: Icons.arrow_back_ios,
                onTap: () {
                  Navigator.pop(context);
                },
                // isGradient: _isDark ?  true : false,
                height: 170, bottomLeft: Get.width / 1.5,
                bottomRight: Get.width / 1.5,
                topRight: 0.0,
                topLeft: 0.0,
              ),
              SizedBox(
                height: Get.height / 2.2,
                child: Center(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Stack(
                        alignment: Alignment.bottomRight,
                        children: [
                          const CircleAvatar(
                            radius: 45,
                            backgroundImage: AssetImage(AppAssets.girl),
                          ),
                          Container(
                            height: 30,
                            width: 30,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: _isDark
                                  ? AppColors.appYellowColor
                                  : AppColors.appRedColor,
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(6.0),
                              child: Image.asset(
                                AppAssets.pencil,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 65.h,
                child: SizedBox(
                    height: 100.h,
                    width: 90.w,
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 22.0, vertical: 15),
                          child: Column(
                            children: [
                              buildListTile(
                                  'Edit Account',
                                      () {},
                                  Colors.white,
                                  Colors.black,
                                  const Icon(
                                    Icons.arrow_forward_ios,
                                    size: 16,
                                  )),
                              buildListTile(
                                'Change Plan',
                                    () {},
                                Colors.white,
                                Colors.black,
                                const Icon(
                                  Icons.arrow_forward_ios,
                                  size: 16,
                                ),
                              ),
                              buildListTile(
                                  'Métricas',
                                      () {
                                    Get.toNamed(RoutesName.metricsScreen);
                                  },
                                  Colors.white,
                                  Colors.black,
                                  const Icon(
                                    Icons.arrow_forward_ios,
                                    size: 16,
                                  )),
                              buildListTile(
                                'Friends',
                                    () {},
                                Colors.grey,
                                Colors.grey,
                                Container(
                                  height: 15,
                                  width: 75,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: _isDark
                                        ? AppColors.appYellowColor
                                        : AppColors.appRedColor,
                                  ),
                                  child: const Center(
                                      child: AppTextWidget(
                                        fontSize: 10,
                                        text: 'Coming soon',
                                        color: Colors.white,
                                      )),
                                ),
                              ),
                              buildListTile(
                                  'Connect with Calendar',
                                      () {},
                                  Colors.grey,
                                  Colors.grey,

                                  Container(
                                    height: 15,
                                    width: 75,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: _isDark
                                          ? AppColors.appYellowColor
                                          : AppColors.appRedColor,
                                    ),
                                    child: const Center(
                                        child: AppTextWidget(
                                          fontSize: 12,
                                          text: 'Coming soon',
                                          color: Colors.white,
                                        )),
                                  )),
                              Container(
                                alignment: Alignment.centerRight,
                                height: 25,
                                width: 75,
                                child: Switch(
                                  value: themeProvider.isDarkMode,
                                  onChanged: (value) {
                                    themeProvider.toggleTheme();
                                  },
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildListTile(String text, Function() onTap,Color? darkColor, Color color, Widget) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40.0, vertical: 10),
        child: Container(
          color: Colors.transparent,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              AppTextWidget(
                text: text,
                fontSize: 14,
                color: color,
                darkColor: darkColor,
                textAlign: TextAlign.start,
              ),
              const SizedBox(
                width: 10,
              ),
              Widget
              //Icon(Icons.arrow_forward_ios, size: 16,),
            ],
          ),
        ),
      ),
    );
  }
}