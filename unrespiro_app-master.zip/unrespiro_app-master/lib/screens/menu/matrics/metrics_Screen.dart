import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';

import '../../../model/res/components/appbarSimple.dart';
import '../../../model/res/components/chartTwo.dart';
import '../../../model/res/constant/app_colors.dart';
import '../../../model/res/widgets/app_text.dart.dart';
import '../../../model/res/widgets/circularpercentindicator.dart';
import '../../../model/res/widgets/customRadio.dart';
import '../../../provider/dropdown/dropdown_provider.dart';
import '../../../provider/matrics_progess/matrics_provider.dart';
import '../../../provider/progress_bar/gradient_bar.dart';
import '../../../provider/progress_bar/progress_bar.dart';
import '../../../provider/theme/theme_provider.dart';

class MetricsScreen extends StatelessWidget {
  MetricsScreen({super.key});


  final List<String> options = ['Weekly', 'Monthly', 'Daily'];

  @override
  Widget build(BuildContext context) {
    final percentageProvider = Provider.of<MatricsPercentageProvider>(context);
    final percentage = percentageProvider.percentage;
    final themeProvider = Provider.of<ThemeProvider>(context);
    final _isDark = themeProvider.isDarkMode;
    final progressData = context.watch<ProgressModel>().progress;
    return Scaffold(
      body: SizedBox(
        height: 100.h,
        child: SingleChildScrollView(
          child: Column(
            children: [
              // AppBar(
              //   actions: [
              //     Switch(
              //       value: themeProvider.isDarkMode,
              //       onChanged: (value) {
              //         themeProvider.toggleTheme();
              //       },
              //     ),
              //   ],
              // ),
              AppbarSimpleWidget(
                text: ' Métricas',
                fontSize: 16,
                textColor: _isDark ? Colors.white:Colors.black,
                color: _isDark ? AppColors.appBarColor:AppColors.appDarkPurpleColor,
                secondColorGradient: _isDark ? AppColors.appBarColor:AppColors.appDarkPurpleColor,
                icon: Icons.arrow_back_ios,onTap: (){
                Get.back();
              },),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          flex: 2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              AppTextWidget(
                                text:
                                'Percentage of usage of your applications:',
                                fontWeight: FontWeight.w500,
                                color: _isDark ? Colors.white : AppColors.appRedColor,
                                fontSize: 12,
                                textAlign: TextAlign.start,
                              ),
                              SizedBox(height: 10),
                              AppTextWidget(
                                text:
                                'Date of first installation:',
                                fontWeight: FontWeight.w500,
                                color: _isDark ? Colors.black:Colors.black,
                                fontSize: 12,textAlign: TextAlign.start,),
                              SizedBox(height: 5),
                              AppTextWidget(
                                  text:
                                  '13/02/2020',
                                  color:  Colors.grey,
                                  fontSize: 12),
                            ],
                          ),
                        ),
                        CircularIndicatorWithEndCircle(percentage: 80,)

                      ],
                    ),
                    SizedBox(height: 40,),
                    AppTextWidget(text: 'Matrics',
                      color: _isDark ? Colors.white: AppColors.appRedColor,
                      fontWeight: FontWeight.w500,fontSize: 14,),
                    buildDropDown(context,0),
                    SizedBox(height:15),
                    LineChartSampleTwo(),
                    //  CartesianChartTwo(title: '',time: '',),
                    SizedBox(height: 20,),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: Row(
                        children: [
                          Container(
                            height: 15,
                            width: 15,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.blue,
                            ),
                          ),
                          SizedBox(width: 10,),
                          Text(
                              'Time of use since the installation of Unrespiro',
                              style:
                              TextStyle(
                                fontSize: 12,
                                color: Colors.grey,
                              )
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 10,),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: Row(
                        children: [
                          Container(
                            height: 15,
                            width: 15,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColors.appYellowColor,
                            ),
                          ),
                          SizedBox(width: 10,),
                          Text(
                              'Time of use before Unrespiro',
                              style:
                              TextStyle(
                                fontSize: 12,
                                color: Colors.grey,
                              )
                          )
                        ],
                      ),
                    ),
                    SizedBox(height: 30,),
                    Stack(
                      children: [
                        Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                AppTextWidget(text: 'Time saved',
                                  color: _isDark ? Colors.white: AppColors.appRedColor,
                                  fontSize: 14,fontWeight: FontWeight.w500,),
                                //buildDropDown(context,1),
                              ],
                            ),
                            SizedBox(height: 30,),
                            buildRow(_isDark, 'Monday:', '30min.'),
                            buildRow(_isDark, 'Tuesday:', '45min.'),
                            buildRow(_isDark, 'Wednesday:', '27min.'),
                            buildRow(_isDark, 'Thursday:', '1hr 10min.'),
                            buildRow(_isDark, 'Friday:', '1hr 30min.'),
                            buildRow(_isDark, 'Saturday:', '40min.'),
                            buildRow(_isDark, 'Sunday:', '10min.'),
                          ],
                        ),
                        buildDropDown(context,1),
                      ],
                    )
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }

  // Consumer<DropdownProvider> buildDropDown(context) {
  //   final themeProvider = Provider.of<ThemeProvider>(context);
  //   final _isDark = themeProvider.isDarkMode;
  //   return Consumer<DropdownProvider>(
  //                builder: (context, dropdownProvider, child) {
  //                  return Align(
  //                    alignment: Alignment.centerRight,
  //                    child: Container(
  //                      width: Get.width/2.8,
  //                      height: 30,
  //                      //padding: EdgeInsets.all(10),
  //                      decoration: BoxDecoration(
  //                        color: _isDark ? AppColors.appBarColor:AppColors.appDarkPurpleColor,
  //                        borderRadius: BorderRadius.circular(40),
  //                        border: Border.all(color: _isDark ? AppColors.appYellowColor : AppColors.appRedColor),
  //                      ),
  //                      child: Column(
  //                        mainAxisSize: MainAxisSize.min,
  //                        children: [
  //                          GestureDetector(
  //                            onTap: () {
  //                              // showDialog(
  //                              //   context: context,
  //                              //   builder: (context) => AlertDialog(
  //                              //     backgroundColor: _isDark ? AppColors.appBarColor:AppColors.appDarkPurpleColor,
  //                              //     alignment: Alignment.centerRight,
  //                              //     content: Column(
  //                              //       mainAxisSize: MainAxisSize.min,
  //                              //       children: options.map((option) {
  //                              //         return RadioListTile<String>(
  //                              //           title: Text(
  //                              //             option,
  //                              //             style: TextStyle(color: _isDark ? Colors.black:Colors.white),
  //                              //           ),
  //                              //           value: option,
  //                              //           groupValue: dropdownProvider.selectedOption,
  //                              //           activeColor: _isDark ? AppColors.appYellowColor : AppColors.appRedColor,
  //                              //           onChanged: (value) {
  //                              //             if (value != null) {
  //                              //               dropdownProvider.setSelectedOption(value);
  //                              //               Navigator.of(context).pop();
  //                              //             }
  //                              //           },
  //                              //         );
  //                              //       }).toList(),
  //                              //     ),
  //                              //   ),
  //                              // );
  //                            },
  //                            child: Row(
  //                              mainAxisAlignment: MainAxisAlignment.spaceAround,
  //                              children: [
  //                                AppTextWidget(
  //                                  text:
  //                                  dropdownProvider.selectedOption,
  //                                 color: _isDark ? Colors.white:Colors.black),
  //                                Icon(
  //                                  Icons.keyboard_arrow_down_rounded,
  //                                  color: Colors.orange,
  //                                ),
  //                              ],
  //                            ),
  //                          ),
  //                        ],
  //                      ),
  //                    ),
  //                  );
  //                },
  //              );
  // }
  Consumer<DropdownProvider> buildDropDown(BuildContext context, int index) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final _isDark = themeProvider.isDarkMode;

    return Consumer<DropdownProvider>(
      builder: (context, dropdownProvider, child) {
        return Stack(
          clipBehavior: Clip.none, // Allows dropdown to overflow
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: Get.width / 2.8,
                    decoration: BoxDecoration(
                      color: _isDark ? AppColors.appBarColor : AppColors.appDarkPurpleColor,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: _isDark ? AppColors.appYellowColor : AppColors.appRedColor,
                        width: 1.0,
                      ),
                    ),
                    child: GestureDetector(
                      onTap: () {
                        dropdownProvider.closeOtherDropdowns(index); // Close other dropdowns
                        dropdownProvider.toggleDropdownVisibility(index);
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          AppTextWidget(
                            text: dropdownProvider.selectedOption,
                            color: _isDark ? Colors.white : Colors.black,
                          ),
                          Icon(
                            Icons.keyboard_arrow_down_rounded,
                            color: _isDark ? AppColors.appYellowColor : AppColors.appRedColor,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (dropdownProvider.isDropdownVisible(index))
              Positioned(
                top: Get.width* 0.070,
                right: 0,
                child: Container(
                  width: Get.width / 2.8,
                  decoration: BoxDecoration(
                    color: _isDark ? AppColors.appBarColor : AppColors.appDarkPurpleColor,
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(10), bottomLeft: Radius.circular(10)),
                    border: Border.all(
                      color: _isDark ? AppColors.appYellowColor : AppColors.appRedColor,
                      width: 1.0,
                    ),
                  ),
                  child: Column(
                    children: options.map((option) {
                      return CustomRadioItem(
                        option: option,
                        groupValue: dropdownProvider.selectedOption,
                        isDark: _isDark,
                        onChanged: (value) {
                          if (value != null) {
                            dropdownProvider.setSelectedOption(value);
                            dropdownProvider.toggleDropdownVisibility(index);
                          }
                        },
                      );
                    }).toList(),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
  Widget buildRow(bool _isDark, day, time) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0, horizontal: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            flex: 1,
            child: Text(
              day,
              style: TextStyle(
                  fontSize: 12,
                  color: _isDark ? Colors.white: Colors.black,
                  fontWeight: FontWeight.w500),
              textAlign: TextAlign.start,
              softWrap: false,
            ),
          ),
          SizedBox(
            width: 5,
          ),
          Expanded(
            flex: 2,
            child: Container(
              width: 100,
              child: GradientProgressIndicator(
                value: 20,
                maxValue: 20 / 240.0,
                minHeight: 8,
              ),
            ),
          ),
          SizedBox(
            width: 10,
          ),
          Expanded(
            flex: 1,
            child: Text(
              time,
              style: TextStyle(
                fontSize: 12,
                color: _isDark ? Colors.grey: Colors.black.withOpacity(0.8),
              ),
              textAlign: TextAlign.start,
              softWrap: false,
            ),
          ),
        ],
      ),
    );
  }

}