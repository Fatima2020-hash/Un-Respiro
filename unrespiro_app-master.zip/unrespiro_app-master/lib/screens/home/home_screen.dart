import 'dart:developer';
import 'dart:ui';

import 'package:device_apps/device_apps.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import 'package:unrespiroapp/constant.dart';

import '../../model/res/components/custom_alertbox_scrollable.dart';
import '../../model/res/constant/app_assets.dart';
import '../../model/res/constant/app_colors.dart';
import '../../model/res/constant/app_string.dart';
import '../../model/res/routes/routes_name.dart';
import '../../model/res/widgets/app_text.dart.dart';
import '../../model/res/widgets/button_widget.dart';
import '../../provider/actions/action_provider.dart';
import '../../provider/app_selection/app_selection_provider.dart';
import '../../provider/theme/theme_provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Application? selectedApp;

  static const platform = MethodChannel('com.example.app/installedApps');

  List<Map<String, dynamic>> installedApps = [];
  List<Application> selectedApps = [];  // Store multiple selected apps
  Set<String> selectedPackages = Set<String>(); // Track selected packages


  // Future<void> getInstalledApps() async {
  //   log('enter');
  //   try {
  //     final List<dynamic> apps = await platform.invokeMethod('getInstalledApps');
  //     setState(() {
  //       // Cast the dynamic list to a list of maps
  //       installedApps = List<Map<String, dynamic>>.from(apps.map((app) => Map<String, dynamic>.from(app)));
  //     });
  //   } on PlatformException catch (e) {
  //     log("Failed to get installed apps: '${e.message}'.");
  //   }
  // }
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final _isDark = themeProvider.isDarkMode;
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.endTop,
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(
            top: 0.0),
        child: FloatingActionButton(
          elevation: 0.0,
          highlightElevation: 0.0,
          backgroundColor: Colors.transparent,
          onPressed: () {
            Provider.of<ActionProvider>(context, listen: false)
                .toggleVisibility();
          },
          child: Consumer<ActionProvider>(
            builder: (context, provider, child) {
              return Visibility(
                  visible: !provider.isVisible,
                  child: _isDark
                      ? Image.asset(
                    AppAssets.gift,
                    height: 50,
                  )
                      : Image.asset(
                    AppAssets.giftR,
                    height: 50,
                  ));
            },
          ),
        ),
      ),
      // appBar: AppBar(
      //   automaticallyImplyLeading: false,
      //   backgroundColor: _isDark?Colors.black:Colors.white,
      //   surfaceTintColor: _isDark?Colors.black: Colors.white,
      //   centerTitle: true,
      //   title:   const AppTextWidget(
      //     text: 'HOME',
      //     fontSize: 14,
      //     fontWeight: FontWeight.w700,
      //   ),
      //   // actions: [
      //   //   Switch(
      //   //     value: themeProvider.isDarkMode,
      //   //     onChanged: (value) {
      //   //       themeProvider.toggleTheme();
      //   //     },
      //   //   ),
      //   // ],
      // ),
      body: SingleChildScrollView(
        child: Stack(
          children: [
            //appBar
            Padding(
              padding: EdgeInsets.all(
                Get.width * 0.0,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 10.h,),
                  SizedBox(
                      width: 100.w,
                      height: 38.h,
                      child: Image.asset(
                        _isDark ? AppAssets.homeMap : AppAssets.homeMapl,
                        fit: BoxFit.cover,

                      )),
                  SizedBox(height: 3.h,),
                  Center(
                    child: ButtonWidget(
                        text: "See Métricas",
                        fontWeight: FontWeight.w700,
                        textSize: 13,
                        onClicked: () {Get.toNamed(RoutesName.metricsScreen);},
                        width: Get.width * 0.35,
                        height: 36.0),
                  ),
                  SizedBox(
                    height:  6.h,
                  ),
                  Column(
                    children: [
                      Container(
                        height: 20.h,
                        width: 90.w,
                        child: Consumer<AppSelectionProvider>(
                          builder: (context, provider, child) {
                            return ListView.builder(
                              shrinkWrap: true,
                              itemCount: provider.selectedApps.length,
                              itemBuilder: (context, index) {
                                Application app = provider.selectedApps[index];
                                return buildStackWidget(
                                  isDark: false,
                                  appName: app.appName,
                                  icon: app is ApplicationWithIcon
                                      ? MemoryImage((app as ApplicationWithIcon).icon)
                                      : null,
                                );
                              },
                            );
                          },
                        ),
                      ),
                      SizedBox(height: 20),
                    ],
                  ),
                  // SizedBox(
                  //   height: 40,
                  //   child: InkWell(
                  //     onTap: () async {
                  //       final app = await Navigator.push<Application>(
                  //         context,
                  //         MaterialPageRoute(builder: (context) => FetchSocialScreen()),
                  //       );
                  //       log('app is: $app');
                  //       if (app != null && !selectedApps.contains(app)) {  // Check to avoid duplicates
                  //         setState(() {
                  //           selectedApps.add(app);  // Add selected app to the list
                  //         });
                  //       }
                  //     },
                  //     child: Icon(
                  //       Icons.add_circle_outline,
                  //       size: 40,
                  //       color: _isDark ? AppColors.appYellowColor : AppColors.appRedColor,
                  //     ),
                  //   ),
                  // ),
                  SizedBox(
                    height: 40,
                    child: InkWell(
                      onTap: () async {
                        // Show the alert dialog with the installed apps
                        await showAppSelectionDialog(context);
                      },
                      child: Icon(
                        Icons.add_circle_outline,
                        size: 40,
                        color: primaryColor, // Change color based on your theme
                      ),
                    ),
                  ),

                  const SizedBox(
                    height: 15,
                  ),
                ],
              ),
            ),
            Positioned(
                top: 5.h,
                left: 45.w,
                child: AppTextWidget(text: 'Home',fontSize:16,fontWeight: FontWeight.w700,color: Colors.black,textAlign: TextAlign.center,)),
            Consumer<ActionProvider>(
              builder: (context, provider, child) {
                return Visibility(
                  visible: provider.isVisible,
                  child: Positioned(
                    top: 2.h,
                    left: 47.w,
                    child: Container(
                      width: Get.width / 2,
                      height: Get.height / 3.2,
                      decoration: BoxDecoration(
                        image: DecorationImage(image: AssetImage(
                            _isDark?
                            AppAssets.giftBG
                                : AppAssets.giftBGWhite),
                        ),
                        // color: _isDark
                        //     ? Colors.grey.withOpacity(0.2)
                        //     : Color(0xffDDD3E6).withOpacity(0.5),5
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Stack(
                        children: <Widget>[
                          Positioned(
                            top: 4.5.h,
                            right: 4.w,
                            child: InkWell(
                              onTap: () {
                                provider.toggleVisibility();
                              },
                              child: Icon(
                                Icons.close,
                                size: 22,
                                color: _isDark ? Colors.white : Colors.black,
                              ),
                            ),
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              SizedBox(height: 2.h,),
                              Image.asset(
                                AppAssets.giftIcon,
                                height: 30,
                                color: _isDark
                                    ? AppColors.appYellowColor
                                    : AppColors.appRedColor,
                              ),
                              SizedBox(height: 2.h),
                              AppTextWidget(
                                text: 'Win a gift',
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                                color: _isDark ? Colors.white : Colors.black,
                              ),
                              SizedBox(height: 1.h),
                              Padding(
                                padding:  EdgeInsets.symmetric(
                                    horizontal: 2.w),
                                child: AppTextWidget(
                                  text:
                                  'Explanation of the reward system for users',
                                  textAlign: TextAlign.center,
                                  fontSize: 10,
                                  color:
                                  _isDark ? Colors.white : Colors.black,
                                ),
                              ),
                              SizedBox(height: 1.h),
                              Container(
                                height: 28,
                                width: 70,
                                decoration: BoxDecoration(
                                  color:  _isDark
                                      ? AppColors.appYellowColor
                                      : AppColors.appRedColor,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child:const Padding(
                                  padding: EdgeInsets.all(3.0),
                                  child: AppTextWidget(
                                    text: 'Ir',
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ) ,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),

          ],
        ),
      ),
    );
  }// Function to display the apps in a dialog and add the selected one
  Future<void> showAppSelectionDialog(BuildContext context) async {
    // Fetch the installed social apps
    List<Application> allApps = await DeviceApps.getInstalledApplications(
      includeAppIcons: true,
      onlyAppsWithLaunchIntent: true,
      includeSystemApps: false,
    );
    List<Application> socialApps = allApps.where((app) => _isSocialApp(app.packageName)).toList();

    // Show the alert dialog with a RawScrollbar
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Applications'),
          content: Container(
            width: double.maxFinite, // Make sure the dialog is wide enough
            height: 300, // Fixed height for the list of apps
            child: RawScrollbar(
              thumbVisibility: true, // Always show the scrollbar
              thickness: 6.0, // Thickness of the scrollbar
              thumbColor: Colors.red, // Customize the scrollbar color
              radius: const Radius.circular(10), // Round scrollbar edges
              child: ListView.builder(
                itemCount: socialApps.length,
                itemBuilder: (context, index) {
                  Application app = socialApps[index];
                  final provider = Provider.of<AppSelectionProvider>(context);
                  bool isSelected = provider.selectedPackages.contains(app.packageName);

                  return ListTile(
                    leading: app is ApplicationWithIcon
                        ? Image.memory(app.icon, width: 48, height: 48)
                        : const Icon(Icons.android),
                    title: Text(app.appName),
                    subtitle: Text(app.packageName),
                    trailing: IconButton(
                      icon: Icon(
                        isSelected ? Icons.check_box : Icons.check_box_outline_blank,
                        color: isSelected ? Colors.green : null,
                      ),
                      onPressed: () {
                        provider.toggleApp(app);
                      },
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }
  // Function to check if the app is a social media app
  bool _isSocialApp(String packageName) {
    List<String> socialAppPackages = [
      'com.facebook.katana',
      'com.instagram.android',
      'com.twitter.android',
      'com.snapchat.android',
      'com.linkedin.android',
      'com.whatsapp',
      'com.pinterest',
      'com.tiktok.android',
      // Add more social media app package names as needed
    ];
    return socialAppPackages.contains(packageName);
  }
  Widget buildStackWidget({required bool isDark, required String appName, ImageProvider? icon}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0),
      child: Stack(
        alignment: Alignment.centerLeft,
        children: [
          Container(
            width: MediaQuery.of(context).size.width * 0.6,
            padding: const EdgeInsets.only(left: 70, top: 10, bottom: 10),
            decoration: BoxDecoration(
              color: isDark ? Colors.black54 : const Color(0xFFDDD3E6),
              borderRadius: BorderRadius.circular(30.0),
            ),
            child: Row(
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'App: $appName',
                      style: TextStyle(
                        fontWeight: FontWeight.w400,
                        fontSize: 12.0,
                        color: isDark ? Colors.white : Colors.black,
                      ),
                    ),
                    Text(
                      'Tiempo ahorrado: 30min.',
                      style: TextStyle(
                        fontSize: 11.0,
                        color: isDark ? Colors.white : Colors.black,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: isDark ? Colors.black : const Color(0xFFDDD3E6),
                  width: 2,
                ),
                borderRadius: BorderRadius.circular(40),
              ),
              child: CircleAvatar(
                backgroundColor: isDark ? Colors.black : Colors.white,
                radius: 28.0,
                backgroundImage: icon,
              ),
            ),
          ),
        ],
      ),
    );
  }  // Stack buildStackWidget(bool _isDark, String image) {

}