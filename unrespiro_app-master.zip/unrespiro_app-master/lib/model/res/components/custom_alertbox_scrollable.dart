import 'package:flutter/material.dart';
import 'package:device_apps/device_apps.dart';

class FetchSocialScreen extends StatefulWidget {
  const FetchSocialScreen({Key? key}) : super(key: key);

  @override
  _FetchSocialScreenState createState() => _FetchSocialScreenState();
}

class _FetchSocialScreenState extends State<FetchSocialScreen> {
  List<Application> _socialApps = [];

  @override
  void initState() {
    super.initState();
    _fetchSocialApps();
  }

  Future<void> _fetchSocialApps() async {
    List<Application> apps = await DeviceApps.getInstalledApplications(
      includeAppIcons: true,
      onlyAppsWithLaunchIntent: true,
      includeSystemApps: false,
    );

    setState(() {
      _socialApps = apps.where((app) => _isSocialApp(app.packageName)).toList();
    });
  }

  // Filter apps based on known social media packages
  bool _isSocialApp(String packageName) {
    List<String> socialAppPackages = [
      'com.facebook.katana',
      'com.instagram.android',
      'com.twitter.android',
      'com.snapchat.android',
      'com.linkedin.android',
      'com.whatsapp',
      'com.pinterest',
      'com.tiktok.android',
      // Add more social media app package names as needed
    ];
    return socialAppPackages.contains(packageName);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Installed Social Apps'),
      ),
      body: ListView.builder(
        itemCount: _socialApps.length,
        itemBuilder: (context, index) {
          Application app = _socialApps[index];
          return ListTile(
            leading: app is ApplicationWithIcon
                ? Image.memory(app.icon, width: 48, height: 48)
                : const Icon(Icons.android),
            title: Text(app.appName),
            subtitle: Text(app.packageName),
            onTap: () {
              // Return the selected app to the previous screen
              Navigator.pop(context, app);
            },
          );
        },
      ),
    );
  }
}
