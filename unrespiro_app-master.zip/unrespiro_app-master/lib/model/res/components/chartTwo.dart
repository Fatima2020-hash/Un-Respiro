import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';

import '../../../provider/theme/theme_provider.dart';
import '../widgets/app_text.dart.dart';

class LineChartSampleTwo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final _isDark = themeProvider.isDarkMode;

    return Container(
      height: 250,
      child: LineChart(
        LineChartData(
          lineBarsData: [
            LineChartBarData(
              spots: [
                FlSpot(0, 30),
                FlSpot(1, 50),
                FlSpot(2, 70),
                FlSpot(3, 60),
                FlSpot(4, 80),
                FlSpot(5, 40),
                FlSpot(6, 60),
                FlSpot(7, 50),
                FlSpot(8, 70),
                FlSpot(9, 60),
                FlSpot(10, 90),
                FlSpot(11, 70),
              ],
              isCurved: true,
              curveSmoothness: 0.1,
              color: Colors.orange,
              barWidth: 2,
              isStrokeCapRound: true,
              dotData: FlDotData(show: false),
              belowBarData: BarAreaData(show: false),
            ),
            LineChartBarData(
              spots: [
                FlSpot(0, 40),
                FlSpot(1, 30),
                FlSpot(2, 60),
                FlSpot(3, 50),
                FlSpot(4, 70),
                FlSpot(5, 40),
                FlSpot(6, 50),
                FlSpot(7, 40),
                FlSpot(8, 60),
                FlSpot(9, 50),
                FlSpot(10, 70),
                FlSpot(11, 60),
              ],
              isCurved: true,
              curveSmoothness: 0.1, // Adjust this value for smoother curves
              color: Colors.blue,
              barWidth: 2,
              isStrokeCapRound: true,
              dotData: FlDotData(show: false),
              belowBarData: BarAreaData(show: false),
            ),
          ],
          titlesData: FlTitlesData(
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  return Text(
                    value.toInt().toString(),
                    style: TextStyle(
                      color: _isDark ? Colors.grey : Colors.black,
                      fontSize: 12,
                    ),
                  );
                },
                reservedSize: 30,
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  switch (value.toInt()) {
                    case 0:
                      return AppTextWidget(text: 'Ene');
                    case 1:
                      return  AppTextWidget(text: 'Feb');
                    case 2:
                      return  AppTextWidget(text: 'Mar');
                    case 3:
                      return  AppTextWidget(text: 'Abr');
                    case 4:
                      return  AppTextWidget(text: 'May');
                    case 5:
                      return  AppTextWidget(text: 'Jun');
                    case 6:
                      return  AppTextWidget(text: 'Jul');
                    case 7:
                      return  AppTextWidget(text: 'Ago');
                    case 8:
                      return  AppTextWidget(text: 'Sep');
                    case 9:
                      return  AppTextWidget(text: 'Oct');
                    case 10:
                      return  AppTextWidget(text: 'Nov');
                    case 11:
                      return  AppTextWidget(text: 'Dic');
                    default:
                      return Text('');
                  }
                },
                reservedSize: 22,
              ),
            ),
            rightTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            topTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
          ),
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            drawHorizontalLine: false,
          ),
          borderData: FlBorderData(
            show: true,
            border: Border(
              left: BorderSide(color: _isDark ? Colors.grey : Colors.black, width: 1),
              bottom: BorderSide(color: _isDark ? Colors.grey : Colors.black, width: 1),
            ),
          ),
          lineTouchData: LineTouchData(enabled: false),
        ),
      ),
    );
  }
}
