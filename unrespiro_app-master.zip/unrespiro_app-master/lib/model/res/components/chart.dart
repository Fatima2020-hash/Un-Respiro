import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import '../../../provider/theme/theme_provider.dart';
import '../constant/app_colors.dart';
import '../widgets/app_text.dart.dart';

class LineChartSample extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final _isDark = themeProvider.isDarkMode;
    return SizedBox(
      height: 300,
      child: LineChart(
        LineChartData(
          lineBarsData: [
            LineChartBarData(
              spots: [
                FlSpot(0, 20),
                FlSpot(1, 10),
                FlSpot(2, 25),
                FlSpot(3, 15),
                FlSpot(4, 35),
                FlSpot(5, 20),
                FlSpot(6, 50),
              ],
              isCurved: true,
              color: _isDark ? AppColors.appYellowColor: Colors.white,
              barWidth: 2,
              belowBarData: BarAreaData(
                show: true,
                color: Colors.transparent,
              ),
              dotData: FlDotData(show: false),
            ),
          ],
          titlesData: FlTitlesData(
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  switch (value.toInt()) {
                    case 0:
                      return AppTextWidget(text:'0', color: Colors.white, fontSize: 10);
                    case 10:
                      return AppTextWidget(text:'00:30', color: Colors.white, fontSize: 10);
                    case 20:
                      return AppTextWidget(text:'00:07', color: Colors.white, fontSize: 10);
                    case 30:
                      return AppTextWidget(text:'00:20', color: Colors.white, fontSize: 10);
                    case 40:
                      return AppTextWidget(text:'00:45', color: Colors.white, fontSize: 10);
                    case 50:
                      return AppTextWidget(text:'00:32', color: Colors.white, fontSize: 10);
                    default:
                      return Text("",style:TextStyle(color: Colors.white, fontSize: 10));
                  }
                },
                reservedSize: 30,
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  switch (value.toInt()) {
                    case 0:
                      return AppTextWidget(text: 'Jan.', color: _isDark ? Colors.grey.shade300:Colors.white, fontSize: 12);
                    case 1:
                      return  AppTextWidget(text:'Feb.', color: Colors.white, fontSize: 12);
                    case 2:
                      return  AppTextWidget(text:'Mar.',color: Colors.white, fontSize: 12);
                    case 3:
                      return  AppTextWidget(text:'Apr.', color: Colors.white, fontSize: 12);
                    case 4:
                      return  AppTextWidget(text:'May.', color: Colors.white, fontSize: 12);
                    case 5:
                      return  AppTextWidget(text:'Jun.', color: Colors.white, fontSize: 12);
                    case 6:
                      return  AppTextWidget(text:'Jul.',color: Colors.white, fontSize: 12);
                    default:
                      return  AppTextWidget(text:'',color: Colors.white, fontSize: 12);
                  }
                },
                reservedSize: 22,
              ),
            ),
            topTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: false,  // Disable the top titles
              ),
            ),
            rightTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: false,  // Disable the right titles
              ),
            ),
          ),
          gridData: FlGridData(
            show: false,
          ),
          borderData: FlBorderData(
            show: true,
            border: Border(
              left: BorderSide(color: _isDark ? Colors.grey.shade300:Colors.white, width: 1),
              bottom: BorderSide(color: _isDark ? Colors.grey.shade300:Colors.white, width: 1),
            ),
          ),
        ),

      ),
    );
  }
}
