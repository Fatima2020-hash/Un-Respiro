class AppAssets{
  static const logoImage  = "assets/images/logo.webp";
  static const lightLogoImage  = "assets/images/light_logo.webp";
  static const mobileImage  = "assets/images/mobile.webp";
  static const mobileBlackImage  = "assets/images/mobileBlack.webp";
  static const lockImage  = "assets/images/lock.webp";
  static const lockImageL  = "assets/images/lock_l.webp";
  static const homeMap  = "assets/images/home_map.webp";
  static const gift  = "assets/images/gift.webp";
  static const giftR  = "assets/images/giftR.webp";
  static const homeMapl  = "assets/images/home_map_l.webp";
  static const phone  = "assets/images/phone_pic.webp";
  static const green_tick  = "assets/images/green_tick.webp";
  static const discord  = "assets/images/discord.webp";
  static const girl  = "assets/images/girl.webp";
  static const clock1  = "assets/images/clockl.webp";
  static const clock  = "assets/images/clock.webp";
  static const permissionBg  = "assets/images/permission_bg.webp";
  static const permissionBgW  = "assets/images/permissionBgW.webp";
  static const background  = "assets/images/background.webp";
  static const loginImage  = "assets/images/login_image.webp";
  static const loginImageWhite  = "assets/images/loginLogoWhite.webp";
  static const loginBackground  = "assets/images/login_bg.webp";
  static const loginBackgroundWhite  = "assets/images/loginBgWgite.webp";
  static const giftBG  = "assets/images/giftBg.webp";
  static const giftBGWhite  = "assets/images/giftBgWhite.webp";
  static const instagramBgWhite  = "assets/images/InstagramBgWhite.webp";
  static const instagramBgBlack  = "assets/images/instagramBgBlack.webp";
  static const moreAlertBox  = "assets/images/moreAlertBox.webp";
  static const permissionBackground  = "assets/images/PERMISOS.webp";
  static const profileRounded  = "assets/images/black_profile_rounded.webp";
  static const whiteProfileRounded  = "assets/images/white_profile_rounded.webp";
  static const blackProfileRounded  = "assets/images/profile_black_shadow.webp";
  static const profileBgWhite  = "assets/images/profile_bg_white.webp";
  static const profileBgBlack  = "assets/images/profile_Bg.webp";
  static const profileBgShadow  = 'assets/images/profile_backShadow.webp';
  static const logoTimer  = 'assets/images/logo_timer.webp';






  ///////////icons/////////////////
  static const dummy  = "assets/icons/dummy.webp";
  static const insta  = "assets/icons/insta.webp";
  static const pinterest  = "assets/icons/pinterest.webp";
  static const delete  = "assets/icons/delete.webp";
  static const pencil  = "assets/icons/pencil.webp";
  static const x  = "assets/icons/x.webp";
  static const tiktok  = "assets/icons/tiktok.webp";
  static const add  = "assets/icons/add.png";
  static const logo  = "assets/icons/logo.webp";
  static const logoN  = "assets/images/logoN.webp";
  static const addL  = "assets/icons/add_l.webp";
  static const giftIcon  = "assets/icons/giftIcon.webp";
  static const home  = "assets/icons/home.png";
  static const menu  = "assets/icons/menu.png";
  static const google  = "assets/icons/google.png";
  static const backIcon  = "assets/icons/back_icon.png";
  static const backIconL  = "assets/icons/backl.png";

}