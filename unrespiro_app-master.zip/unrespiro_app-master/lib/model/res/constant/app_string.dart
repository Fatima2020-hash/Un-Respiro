class AppString {
  static const confirm_text = "Tutorial de uso de la aplicacion. Texto tutorial de uso de la aplicacion. Texto tutorial de uso de la aplicacion";
  static const permissiom_text = "Your data will be safe.";
}