import 'dart:async';
import 'dart:developer';
import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:permission_handler/permission_handler.dart';

class BackgroundService {
  static final BackgroundService _instance = BackgroundService._internal();

  factory BackgroundService() => _instance;

  BackgroundService._internal();

  Future<void> initializeService() async {
    // Request foreground service and notification permissions before starting service
    if (await _requestPermissions()) {
      final service = FlutterBackgroundService();

      service.configure(
        androidConfiguration: AndroidConfiguration(
          onStart: onStart,
          autoStart: true,
          isForegroundMode: true,
        ),
        iosConfiguration: IosConfiguration(
          onForeground: onStart,
          onBackground: onIosBackground,
        ),
      );

      service.startService();
    }
  }

  @pragma('vm:entry-point')
  Future<bool> onIosBackground(ServiceInstance service) async{
    WidgetsFlutterBinding.ensureInitialized();
    DartPluginRegistrant.ensureInitialized();
    return true;
  }

  @pragma('vm:entry-point')
  static void onStart(ServiceInstance service) async {
    DartPluginRegistrant.ensureInitialized();
    if (service is AndroidServiceInstance) {
      service.on('setAsForeground').listen((event) {
      service.setAsForegroundService();
      });
      service.on('setAsBackground').listen((event) {
        service.setAsBackgroundService();
      });
      service.on('stopService').listen((event) {
        service.stopSelf();
      });
    }

    // Continuously running task
    // service.on('update').listen((event) {
    //   log("Background Service Running");
    // });

    Timer.periodic(const Duration(seconds: 1), (timer) async {
      if (service is AndroidServiceInstance) {
        if(await service.isForegroundService()){
          service.setForegroundNotificationInfo(
              title: "Unrespiro",
              content: "Foreground Services Running"
          );
        }
      }
      log("Background Service Running");
      service.invoke('update');
    });

  }

  Future<void> stopService() async {
    final service = FlutterBackgroundService();
    service.invoke("stop");
  }

  // Request necessary permissions
  Future<bool> _requestPermissions() async {
    // Request notification permission (required for Android 13+)
    if (await Permission.notification.isDenied) {
      final status = await Permission.notification.request();
      if (status.isDenied) return false;
    }

    // Request foreground service permission (required for Android 13+)
    if (await Permission.notification.isDenied) {
      final status = await Permission.notification.request();
      if (status.isDenied) return false;
    }

    return true; // Permissions granted
  }
}
