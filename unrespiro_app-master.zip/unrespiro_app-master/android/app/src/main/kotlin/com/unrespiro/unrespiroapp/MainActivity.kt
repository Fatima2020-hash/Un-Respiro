package com.unrespiro.unrespiroapp

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.plugin.common.MethodChannel
import io.flutter.embedding.engine.FlutterEngine
import java.util.ArrayList

class MainActivity : FlutterActivity() {
    companion object {
        private const val CHANNEL = "com.example.app/installedApps"

    }

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "getInstalledApps") {
                val installedApps = getInstalledApps()
                result.success(installedApps)
            } else {
                result.notImplemented()
            }
        }
    }

    private fun getInstalledApps(): List<String> {
        val pm: PackageManager = packageManager
        val apps: List<ApplicationInfo> = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val appNames = ArrayList<String>()

        for (appInfo in apps) {
            // Filter out system apps if needed
            if (appInfo.flags and ApplicationInfo.FLAG_SYSTEM == 0) {
                val appName = pm.getApplicationLabel(appInfo).toString()
                appNames.add(appName)
            }
        }
        return appNames
    }
}